
# 📊 Bike Sharing Dashboard

Dashboard ini merupakan bagian dari submission proyek analisis data menggunakan **Streamlit**, yang bertujuan untuk memvisualisasikan pola penyewaan sepeda berdasarkan musim dan kondisi cuaca.

## 📁 Struktur Proyek

```
BikeSharingDashboard/
│
├── main.py               # File utama untuk menjalankan dashboard Streamlit
├── requirements.txt      # Daftar dependensi yang dibutuhkan
├── day.csv               # Dataset penyewaan sepeda
└── README.md             # Dokumentasi proyek ini
```

## 🚀 Cara Menjalankan Proyek

1. **Clone atau buka folder proyek ini di komputer Anda.**

2. **(Opsional) Buat virtual environment:**
   ```bash
   python -m venv venv
   venv\Scripts\activate  # Windows
   source venv/bin/activate  # macOS/Linux
   ```

3. **Install dependensi:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Jalankan aplikasi Streamlit:**
   ```bash
   streamlit run main.py
   ```

5. Aplikasi akan terbuka otomatis di browser pada `http://localhost:8501`

## 📌 Fitur Dashboard

- **Filter Musim:** Memilih data berdasarkan musim
- **Distribusi Penyewaan Sepeda per Musim (Boxplot)**
- **Rata-rata Penyewaan Sepeda per Musim (Barplot)**
- **Pengaruh Temperatur terhadap Penyewaan (Scatterplot)**
- **Korelasi Antar Variabel (Heatmap)**
- **Tombol Download Gambar Visualisasi**

## 📂 Dataset
Dataset yang digunakan adalah `day.csv`, berisi data harian penyewaan sepeda dengan berbagai fitur seperti:
- `season`, `temp`, `cnt`, dll.

## 🙌 Kontributor
Arieffathin Abrar

## 📄 Lisensi
Proyek ini dibuat untuk keperluan edukasi dan submission pelatihan analisis data.
