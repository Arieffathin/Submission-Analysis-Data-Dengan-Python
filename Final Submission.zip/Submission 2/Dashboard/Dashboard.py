import streamlit as st
import pandas as pd
import numpy as np  # Tambahkan ini
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
day_df = pd.read_csv("D:\Dashboard\day.csv")

# Judul Dashboard
st.title("SubmissionBike Sharing Dashboard")
st.write("Analisis data penyewaan sepeda berdasarkan musim dan kondisi cuaca.")

# Sidebar untuk filter
season_mapping = {1: "Spring", 2: "Summer", 3: "Fall", 4: "Winter"}
day_df["season"] = day_df["season"].map(season_mapping)
selected_season = st.sidebar.selectbox("Pilih Musim:", day_df["season"].unique())
filtered_data = day_df[day_df["season"] == selected_season]

# Visualisasi Pola Penyewaan Sepeda
st.subheader("Distribusi Penyewaan Sepeda Berdasarkan Musim")
fig, ax = plt.subplots()
sns.boxplot(x="season", y="cnt", data=day_df, ax=ax)
st.pyplot(fig)

st.subheader("Rata-rata Penyewaan Sepeda per Musim")
fig, ax = plt.subplots()
sns.barplot(x="season", y="cnt", data=day_df, estimator=np.mean, ax=ax)  # Gunakan np.mean
st.pyplot(fig)

# Pengaruh Cuaca terhadap Penyewaan Sepeda
st.subheader("Hubungan Temperatur dengan Penyewaan Sepeda")
fig, ax = plt.subplots()
sns.scatterplot(x="temp", y="cnt", data=day_df, ax=ax)
st.pyplot(fig)

# **PERBAIKAN: Hapus kolom non-numerik sebelum membuat heatmap**
numeric_df = day_df.select_dtypes(include=[np.number])

st.subheader("Korelasi Antar Variabel")
fig, ax = plt.subplots(figsize=(8,6))
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", ax=ax)
st.pyplot(fig)

import io


buffer = io.BytesIO()
fig.savefig(buffer, format="png")
buffer.seek(0)

st.download_button(
    label="Download Gambar",
    data=buffer,
    file_name="dashboard.png",
    mime="image/png"
)


